plugins {
    id("com.android.application")
}

android {
    namespace = "de.quizabend.buzzer"
    compileSdk = 34

    defaultConfig {
        applicationId = "de.quizabend.buzzer"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "2.0"
    }

    // Fester Schlüssel, damit spätere Versionen sich über die alte installieren lassen
    signingConfigs {
        create("buzzer") {
            storeFile = file("buzzer.jks")
            storePassword = "buzzer123"
            keyAlias = "buzzer"
            keyPassword = "buzzer123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("buzzer")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("buzzer")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

// Keine Zusatz-Bibliotheken: Die Verbindung läuft über das normale WLAN (LanNet.java)
