plugins {
    id("com.android.application")
}

android {
    namespace = "de.quizabend.buzzer"
    compileSdk = 34

    defaultConfig {
        applicationId = "de.quizabend.buzzer"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Fester Schlüssel, damit spätere Versionen sich über die alte installieren lassen
    signingConfigs {
        create("buzzer") {
            storeFile = file("buzzer.jks")
            storePassword = "buzzer123"
            keyAlias = "buzzer"
            keyPassword = "buzzer123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("buzzer")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("buzzer")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // Google Nearby Connections: Bluetooth, BLE und WLAN direkt zwischen den Handys
    implementation("com.google.android.gms:play-services-nearby:19.0.0")
}
