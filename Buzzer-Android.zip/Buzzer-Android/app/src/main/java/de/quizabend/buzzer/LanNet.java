package de.quizabend.buzzer;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * WLAN-Verbindung für den Buzzer – ohne Internet und ohne Google-Dienste.
 *
 * Ein Handy öffnet den Raum: Es nimmt auf TCP-Port 47811 Verbindungen an und ruft jede Sekunde
 * per UDP-Broadcast (Port 47810) „hier ist Raum quiz“ ins WLAN. Die anderen Handys hören auf
 * diese Rufe, verbinden sich per TCP und tauschen zeilenweise kurze JSON-Nachrichten aus.
 * Blockt ein WLAN die Rufe, kann man die angezeigte Adresse eintippen.
 *
 * Alle Methoden sind threadsicher; Rückmeldungen kommen auf Hintergrund-Threads.
 */
public final class LanNet {

    public interface Listener {
        void onConnected(String endpoint);

        void onDisconnected(String endpoint);

        void onMessage(String endpoint, String data);

        void onStatus(String text);

        void onAddress(String text);

        void onError(String text);
    }

    public static final int DISCOVERY_PORT = 47810;
    public static final int GAME_PORT = 47811;
    private static final String MAGIC = "BUZZER2";
    private static final int READ_TIMEOUT_MS = 15000;
    private static final long HEARTBEAT_SECONDS = 4;

    private final Listener listener;
    private final Object lock = new Object();

    private volatile boolean running = false;
    private volatile boolean hub = false;
    private volatile int generation = 0;
    private volatile String room = "quiz";
    private volatile String name = "Buzzer";

    private ServerSocket server;
    private final Map<String, Conn> clients = new ConcurrentHashMap<>();
    private final AtomicInteger nextId = new AtomicInteger(1);

    private volatile Conn hubConn;
    private volatile DatagramSocket listenSocket;
    private volatile String manualHost;
    private volatile InetSocketAddress foundHost;
    private int discoverGen = -1;

    public LanNet(Listener listener) {
        this.listener = listener;
    }

    // ------------------------------------------------------------------ Raum öffnen

    public void startHub(String roomCode, String displayName) {
        stop();
        final int gen;
        final ServerSocket s;
        synchronized (lock) {
            room = clean(roomCode, "quiz");
            name = clean(displayName, "Buzzer");
            hub = true;
            running = true;
            gen = ++generation;
            try {
                server = openServer();
            } catch (IOException e) {
                running = false;
                listener.onError("Der Raum konnte nicht geöffnet werden. Ist das WLAN an?");
                return;
            }
            s = server;
        }
        spawn("buzzer-accept", () -> acceptLoop(s, gen));
        spawn("buzzer-beacon", () -> beaconLoop(s.getLocalPort(), gen));
        listener.onStatus("Raum „" + room + "“ ist offen. Warte auf Mitspieler …");
        listener.onAddress(addressText(s.getLocalPort()));
    }

    private static ServerSocket openServer() throws IOException {
        ServerSocket s = new ServerSocket();
        s.setReuseAddress(true);
        try {
            s.bind(new InetSocketAddress(GAME_PORT));
        } catch (IOException busy) {
            s.close();
            s = new ServerSocket();
            s.setReuseAddress(true);
            s.bind(new InetSocketAddress(0));
        }
        return s;
    }

    private void acceptLoop(ServerSocket s, int gen) {
        while (alive(gen)) {
            try {
                Socket sock = s.accept();
                sock.setTcpNoDelay(true);
                sock.setSoTimeout(READ_TIMEOUT_MS);
                if (!alive(gen)) {
                    closeQuietly(sock);
                    break;
                }
                String id = "c" + nextId.getAndIncrement();
                Conn c = new Conn(id, sock, gen);
                clients.put(id, c);
                c.start();
                listener.onConnected(id);
            } catch (IOException e) {
                if (!alive(gen)) break;
                sleep(200);
            }
        }
    }

    private void beaconLoop(int port, int gen) {
        try (DatagramSocket ds = new DatagramSocket()) {
            ds.setBroadcast(true);
            while (alive(gen)) {
                byte[] msg = (MAGIC + "\t" + room + "\t" + port + "\t" + name).getBytes(StandardCharsets.UTF_8);
                for (InetAddress target : broadcastTargets()) {
                    try {
                        ds.send(new DatagramPacket(msg, msg.length, target, DISCOVERY_PORT));
                    } catch (IOException ignored) {
                        // dieses Netz nimmt keinen Broadcast, die anderen trotzdem versuchen
                    }
                }
                sleep(1000);
            }
        } catch (IOException e) {
            listener.onStatus("Andere Handys finden den Raum nicht automatisch. Sie können die Adresse eintippen.");
        }
    }

    // ------------------------------------------------------------------ Raum beitreten

    public void startSpoke(String roomCode, String displayName) {
        stop();
        final int gen;
        synchronized (lock) {
            room = clean(roomCode, "quiz");
            name = clean(displayName, "Buzzer");
            hub = false;
            running = true;
            gen = ++generation;
        }
        startDiscovery(gen, 0);
    }

    /** Port des offenen Raums, sonst -1 (für die Anmeldung bei der Android-Netzwerksuche). */
    public int hubPort() {
        synchronized (lock) {
            return (hub && running && server != null) ? server.getLocalPort() : -1;
        }
    }

    /** Ein Raum, der auf anderem Weg gefunden wurde (Android-Netzwerksuche). */
    public void connectFound(InetAddress addr, int port) {
        if (addr == null || port <= 0 || port > 65535 || hub) return;
        foundHost = new InetSocketAddress(addr, port);
    }

    /** Adresse von Hand: „192.168.178.42“ oder „192.168.178.42:47811“. */
    public void connectManual(String host) {
        if (host == null) return;
        String h = host.trim();
        if (!h.isEmpty()) manualHost = h;
    }

    private void startDiscovery(final int gen, final long delayMs) {
        synchronized (lock) {
            if (discoverGen == gen) return; // für diese Sitzung sucht schon jemand
            discoverGen = gen;
        }
        spawn("buzzer-discover", () -> {
            try {
                if (delayMs > 0) sleep(delayMs);
                discoverLoop(gen);
            } finally {
                synchronized (lock) {
                    if (discoverGen == gen) discoverGen = -1;
                }
            }
        });
    }

    private void discoverLoop(int gen) {
        if (!alive(gen) || hubConn != null) return;
        listener.onStatus("Suche Raum „" + room + "“ im WLAN …");
        long started = System.currentTimeMillis();
        boolean hinted = false;
        DatagramSocket ds = null;
        try {
            ds = new DatagramSocket(null);
            ds.setReuseAddress(true);
            ds.setBroadcast(true);
            ds.setSoTimeout(1000);
            ds.bind(new InetSocketAddress(DISCOVERY_PORT));
            listenSocket = ds;
        } catch (IOException e) {
            if (ds != null) ds.close();
            ds = null;
            listener.onStatus("Automatische Suche nicht möglich. Tippe die Adresse des Raum-Handys ein.");
        }
        byte[] buf = new byte[512];
        try {
            while (alive(gen) && hubConn == null) {
                InetSocketAddress found = foundHost;
                if (found != null) {
                    foundHost = null;
                    listener.onStatus("Raum gefunden, verbinde …");
                    if (connect(found.getAddress(), found.getPort(), gen)) break;
                }
                String manual = manualHost;
                if (manual != null) {
                    manualHost = null;
                    listener.onStatus("Verbinde mit " + manual + " …");
                    if (connectTo(manual, gen)) break;
                    listener.onStatus("Unter " + manual + " ist kein Raum offen. Stimmt die Adresse?");
                }
                if (ds == null) {
                    sleep(300);
                    continue;
                }
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    ds.receive(p);
                    String[] f = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8).split("\t");
                    if (f.length >= 3 && MAGIC.equals(f[0]) && room.equals(f[1])) {
                        int port = Integer.parseInt(f[2].trim());
                        listener.onStatus("Raum gefunden, verbinde …");
                        if (connect(p.getAddress(), port, gen)) break;
                        listener.onStatus("Verbinden hat nicht geklappt, versuche es weiter …");
                    }
                } catch (SocketTimeoutException timeout) {
                    // weiter warten
                } catch (NumberFormatException foreign) {
                    // fremdes Paket
                } catch (IOException e) {
                    if (!alive(gen)) break;
                    sleep(300);
                }
                if (!hinted && hubConn == null && System.currentTimeMillis() - started > 8000) {
                    hinted = true;
                    listener.onStatus("Noch kein Raum gefunden. Sind alle im selben WLAN? Sonst die Adresse eintippen.");
                }
            }
        } finally {
            if (ds != null) ds.close();
            if (listenSocket == ds) listenSocket = null;
        }
    }

    private boolean connectTo(String hostAndPort, int gen) {
        String host = hostAndPort;
        int port = GAME_PORT;
        int colon = hostAndPort.lastIndexOf(':');
        if (colon > 0 && hostAndPort.indexOf(':') == colon) {
            try {
                port = Integer.parseInt(hostAndPort.substring(colon + 1).trim());
                host = hostAndPort.substring(0, colon).trim();
            } catch (NumberFormatException ignored) {
                // dann ohne Port
            }
        }
        try {
            return connect(InetAddress.getByName(host), port, gen);
        } catch (IOException e) {
            return false;
        }
    }

    private boolean connect(InetAddress addr, int port, int gen) {
        Socket sock = new Socket();
        try {
            sock.connect(new InetSocketAddress(addr, port), 3000);
            sock.setTcpNoDelay(true);
            sock.setSoTimeout(READ_TIMEOUT_MS);
        } catch (IOException e) {
            closeQuietly(sock);
            return false;
        }
        if (!alive(gen)) {
            closeQuietly(sock);
            return false;
        }
        Conn c = new Conn("hub", sock, gen);
        hubConn = c;
        c.start();
        listener.onConnected("hub");
        return true;
    }

    // ------------------------------------------------------------------ Senden und Beenden

    public void sendTo(String endpoint, String data) {
        if (!running || endpoint == null || data == null) return;
        Conn c = hub ? clients.get(endpoint) : ("hub".equals(endpoint) ? hubConn : null);
        if (c != null) c.send(data);
    }

    /** Raum-Handy: an alle. Mitspieler: an das Raum-Handy. */
    public void broadcast(String data) {
        if (!running || data == null) return;
        if (hub) {
            for (Conn c : clients.values()) c.send(data);
        } else {
            Conn c = hubConn;
            if (c != null) c.send(data);
        }
    }

    public void stop() {
        ServerSocket s;
        DatagramSocket ls;
        Conn h;
        List<Conn> cs;
        synchronized (lock) {
            running = false;
            generation++;
            s = server;
            server = null;
            ls = listenSocket;
            listenSocket = null;
            h = hubConn;
            hubConn = null;
            cs = new ArrayList<>(clients.values());
            clients.clear();
            manualHost = null;
            foundHost = null;
        }
        if (s != null) {
            try {
                s.close();
            } catch (IOException ignored) {
                // schon zu
            }
        }
        if (ls != null) ls.close();
        if (h != null) h.close();
        for (Conn c : cs) c.close();
    }

    private boolean alive(int gen) {
        return running && gen == generation;
    }

    // ------------------------------------------------------------------ eine Verbindung

    private final class Conn {
        final String id;
        final Socket socket;
        final int gen;
        final LinkedBlockingQueue<String> queue = new LinkedBlockingQueue<>();
        final AtomicBoolean open = new AtomicBoolean(true);

        Conn(String id, Socket socket, int gen) {
            this.id = id;
            this.socket = socket;
            this.gen = gen;
        }

        void start() {
            spawn("buzzer-read-" + id, this::readLoop);
            spawn("buzzer-write-" + id, this::writeLoop);
        }

        void send(String line) {
            if (open.get()) queue.offer(line);
        }

        private void readLoop() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while (open.get() && (line = in.readLine()) != null) {
                    if (!line.isEmpty() && alive(gen)) listener.onMessage(id, line);
                }
            } catch (IOException ignored) {
                // Verbindung weg oder 15 s lang nichts gehört
            } finally {
                close();
            }
        }

        private void writeLoop() {
            try {
                OutputStream out = new BufferedOutputStream(socket.getOutputStream());
                while (open.get()) {
                    String line = queue.poll(HEARTBEAT_SECONDS, TimeUnit.SECONDS);
                    if (!open.get()) break;
                    String text = line == null ? "" : line.replace('\n', ' ').replace('\r', ' ');
                    out.write((text + "\n").getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
            } catch (IOException | InterruptedException ignored) {
                // Verbindung weg
            } finally {
                close();
            }
        }

        void close() {
            if (!open.compareAndSet(true, false)) return;
            closeQuietly(socket);
            queue.offer("");
            connClosed(this);
        }
    }

    private void connClosed(Conn c) {
        if (!alive(c.gen)) return;
        if (hub) {
            if (clients.remove(c.id) != null) listener.onDisconnected(c.id);
        } else if (hubConn == c) {
            hubConn = null;
            listener.onDisconnected("hub");
            listener.onStatus("Verbindung zum Raum verloren, suche neu …");
            startDiscovery(c.gen, 1000);
        }
    }

    // ------------------------------------------------------------------ Hilfen

    private static void spawn(String threadName, Runnable r) {
        Thread t = new Thread(r, threadName);
        t.setDaemon(true);
        t.start();
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static void closeQuietly(Socket s) {
        try {
            s.close();
        } catch (IOException ignored) {
            // egal
        }
    }

    private static String clean(String s, String fallback) {
        if (s == null) return fallback;
        String t = s.replaceAll("\\p{Cntrl}", " ").trim();
        if (t.length() > 40) t = t.substring(0, 40);
        return t.isEmpty() ? fallback : t;
    }

    static List<InetAddress> broadcastTargets() {
        List<InetAddress> out = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            if (en != null) {
                for (NetworkInterface ni : Collections.list(en)) {
                    if (!ni.isUp() || ni.isLoopback()) continue;
                    for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                        InetAddress b = ia.getBroadcast();
                        if (b != null && !out.contains(b)) out.add(b);
                    }
                }
            }
        } catch (SocketException | RuntimeException ignored) {
            // dann nur der allgemeine Broadcast
        }
        try {
            InetAddress all = InetAddress.getByName("255.255.255.255");
            if (!out.contains(all)) out.add(all);
        } catch (IOException ignored) {
            // kann bei einer festen Adresse nicht passieren
        }
        return out;
    }

    static List<String> localAddresses() {
        List<String> out = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            if (en != null) {
                for (NetworkInterface ni : Collections.list(en)) {
                    if (!ni.isUp() || ni.isLoopback()) continue;
                    for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                        InetAddress a = ia.getAddress();
                        if (a instanceof Inet4Address && !a.isLoopbackAddress() && !out.contains(a.getHostAddress())) {
                            out.add(a.getHostAddress());
                        }
                    }
                }
            }
        } catch (SocketException | RuntimeException ignored) {
            // keine Adresse bekannt
        }
        return out;
    }

    private static String addressText(int port) {
        String suffix = port == GAME_PORT ? "" : ":" + port;
        StringBuilder sb = new StringBuilder();
        for (String a : localAddresses()) {
            if (sb.length() > 0) sb.append(" oder ");
            sb.append(a).append(suffix);
        }
        return sb.toString();
    }
}
