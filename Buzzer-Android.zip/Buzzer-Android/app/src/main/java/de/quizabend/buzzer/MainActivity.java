package de.quizabend.buzzer;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Buzzer für den Quizabend.
 *
 * Die Oberfläche ist eine Webseite (assets/index.html). Diese Activity verbindet die Handys
 * über Google Nearby Connections (Bluetooth, BLE und WLAN direkt, ohne Internet) als Stern:
 * Das Handy, das den Raum öffnet, ist der Mittelpunkt, alle anderen verbinden sich damit.
 * Die Nachrichten selbst wertet die Webseite aus; hier werden sie nur durchgereicht.
 */
public class MainActivity extends Activity {

    private static final String SERVICE_ID = "de.quizabend.buzzer";
    private static final int REQ_PERMISSIONS = 42;

    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private ConnectionsClient nearby;

    private boolean running = false;
    private boolean hub = false;
    private boolean discovering = false;
    private String room = "quiz";
    private String myName = "Buzzer";
    private String hubEndpoint = null;
    private final Set<String> spokes = new HashSet<>();
    private final Set<String> pending = new HashSet<>();
    private Runnable afterPermissions = null;

    private final Runnable retry = () -> {
        if (running && !hub && hubEndpoint == null && pending.isEmpty()) startDiscovery();
    };

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        nearby = Nearby.getConnectionsClient(this);

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(22, 17, 58));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidNet");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        // Erst die Webseite fragen (z. B. Raum verlassen), sonst App schließen
        web.evaluateJavascript("window.__back ? window.__back() : false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        stopNet();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    // ---------------------------------------------------------------- Brücke zur Webseite

    private class Bridge {
        @JavascriptInterface
        public void startHub(String roomCode, String name) {
            main.post(() -> startNet(true, roomCode, name));
        }

        @JavascriptInterface
        public void startSpoke(String roomCode, String name) {
            main.post(() -> startNet(false, roomCode, name));
        }

        @JavascriptInterface
        public void stop() {
            main.post(MainActivity.this::stopNet);
        }

        @JavascriptInterface
        public void send(String endpointId, String data) {
            main.post(() -> sendTo(endpointId, data));
        }

        @JavascriptInterface
        public void broadcast(String data) {
            main.post(() -> sendAll(data));
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            main.post(() -> buzz(ms));
        }
    }

    // ---------------------------------------------------------------- Verbindung

    private void startNet(boolean asHub, String roomCode, String name) {
        stopNet();
        hub = asHub;
        room = (roomCode == null || roomCode.isEmpty()) ? "quiz" : roomCode;
        myName = (name == null || name.isEmpty()) ? "Buzzer" : name;
        withPermissions(() -> {
            running = true;
            if (hub) startAdvertising();
            else startDiscovery();
        });
    }

    private void stopNet() {
        running = false;
        main.removeCallbacks(retry);
        if (nearby != null) {
            nearby.stopAdvertising();
            nearby.stopDiscovery();
            nearby.stopAllEndpoints();
        }
        discovering = false;
        hubEndpoint = null;
        spokes.clear();
        pending.clear();
    }

    private String endpointName() {
        return room + "|" + myName;
    }

    private boolean sameRoom(String endpointName) {
        return endpointName != null && endpointName.startsWith(room + "|");
    }

    private void startAdvertising() {
        AdvertisingOptions options = new AdvertisingOptions.Builder().setStrategy(Strategy.P2P_STAR).build();
        nearby.startAdvertising(endpointName(), SERVICE_ID, lifecycle, options)
                .addOnSuccessListener(unused -> status("Raum „" + room + "“ ist offen. Warte auf Mitspieler …"))
                .addOnFailureListener(e -> error("Der Raum konnte nicht geöffnet werden. Sind Bluetooth und WLAN an?"));
    }

    private void startDiscovery() {
        if (discovering || !running || hub) return;
        discovering = true;
        DiscoveryOptions options = new DiscoveryOptions.Builder().setStrategy(Strategy.P2P_STAR).build();
        nearby.startDiscovery(SERVICE_ID, discovery, options)
                .addOnSuccessListener(unused -> status("Suche Raum „" + room + "“ …"))
                .addOnFailureListener(e -> {
                    discovering = false;
                    status("Suche klappt gerade nicht. Sind Bluetooth und WLAN an?");
                    scheduleRetry(3000);
                });
    }

    private void scheduleRetry(long delayMs) {
        main.removeCallbacks(retry);
        if (running && !hub) main.postDelayed(retry, delayMs);
    }

    private void restartSearch(long delayMs) {
        nearby.stopDiscovery();
        discovering = false;
        scheduleRetry(delayMs);
    }

    private final EndpointDiscoveryCallback discovery = new EndpointDiscoveryCallback() {
        @Override
        public void onEndpointFound(String endpointId, DiscoveredEndpointInfo info) {
            if (!running || hub || hubEndpoint != null || !pending.isEmpty()) return;
            if (!sameRoom(info.getEndpointName())) return;
            pending.add(endpointId);
            status("Raum gefunden, verbinde …");
            nearby.requestConnection(endpointName(), endpointId, lifecycle)
                    .addOnFailureListener(e -> {
                        pending.remove(endpointId);
                        status("Verbinden hat nicht geklappt, versuche es erneut …");
                        restartSearch(1500);
                    });
        }

        @Override
        public void onEndpointLost(String endpointId) {
            // nichts zu tun
        }
    };

    private final ConnectionLifecycleCallback lifecycle = new ConnectionLifecycleCallback() {
        @Override
        public void onConnectionInitiated(String endpointId, ConnectionInfo info) {
            if (!running || (hub && !sameRoom(info.getEndpointName()))) {
                nearby.rejectConnection(endpointId);
                return;
            }
            nearby.acceptConnection(endpointId, payloads);
        }

        @Override
        public void onConnectionResult(String endpointId, ConnectionResolution result) {
            pending.remove(endpointId);
            if (!running) return;
            boolean ok = result.getStatus().getStatusCode() == ConnectionsStatusCodes.STATUS_OK;
            if (ok) {
                if (hub) {
                    spokes.add(endpointId);
                } else {
                    hubEndpoint = endpointId;
                    nearby.stopDiscovery();
                    discovering = false;
                }
                event("connected", "endpoint", endpointId);
            } else if (!hub) {
                status("Verbinden hat nicht geklappt, versuche es erneut …");
                restartSearch(1500);
            }
        }

        @Override
        public void onDisconnected(String endpointId) {
            if (hub) {
                if (spokes.remove(endpointId)) event("disconnected", "endpoint", endpointId);
            } else if (endpointId.equals(hubEndpoint)) {
                hubEndpoint = null;
                event("disconnected", "endpoint", endpointId);
                restartSearch(1000);
            }
        }
    };

    private final PayloadCallback payloads = new PayloadCallback() {
        @Override
        public void onPayloadReceived(String endpointId, Payload payload) {
            if (payload.getType() != Payload.Type.BYTES) return;
            byte[] bytes = payload.asBytes();
            if (bytes == null) return;
            event("msg", "endpoint", endpointId, "data", new String(bytes, StandardCharsets.UTF_8));
        }

        @Override
        public void onPayloadTransferUpdate(String endpointId, PayloadTransferUpdate update) {
            // kleine Nachrichten, kein Fortschritt nötig
        }
    };

    private void sendTo(String endpointId, String data) {
        if (!running || endpointId == null || data == null) return;
        nearby.sendPayload(endpointId, Payload.fromBytes(data.getBytes(StandardCharsets.UTF_8)));
    }

    private void sendAll(String data) {
        if (!running || data == null) return;
        if (hub) {
            if (!spokes.isEmpty()) {
                nearby.sendPayload(new ArrayList<>(spokes), Payload.fromBytes(data.getBytes(StandardCharsets.UTF_8)));
            }
        } else if (hubEndpoint != null) {
            sendTo(hubEndpoint, data);
        }
    }

    // ---------------------------------------------------------------- Meldungen an die Webseite

    private void status(String text) {
        event("status", "text", text);
    }

    private void error(String text) {
        event("error", "text", text);
    }

    private void event(String type, String... keyValues) {
        StringBuilder sb = new StringBuilder("{\"type\":").append(JSONObject.quote(type));
        for (int i = 0; i + 1 < keyValues.length; i += 2) {
            sb.append(',').append(JSONObject.quote(keyValues[i])).append(':').append(JSONObject.quote(keyValues[i + 1]));
        }
        sb.append('}');
        final String js = "window.__native && window.__native(" + sb + ")";
        main.post(() -> {
            if (web != null) web.evaluateJavascript(js, null);
        });
    }

    // ---------------------------------------------------------------- Vibration

    private void buzz(int ms) {
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) return;
        v.vibrate(VibrationEffect.createOneShot(Math.max(1, Math.min(ms, 1500)), VibrationEffect.DEFAULT_AMPLITUDE));
    }

    // ---------------------------------------------------------------- Berechtigungen

    private void withPermissions(Runnable then) {
        Set<String> declared = declaredPermissions();
        List<String> missing = new ArrayList<>();
        for (String p : requiredPermissions()) {
            if (declared.contains(p) && checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (missing.isEmpty()) {
            then.run();
            return;
        }
        afterPermissions = then;
        requestPermissions(missing.toArray(new String[0]), REQ_PERMISSIONS);
    }

    private List<String> requiredPermissions() {
        List<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            p.add(Manifest.permission.BLUETOOTH_SCAN);
            p.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            p.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            p.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        } else {
            p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        return p;
    }

    /** Nur Berechtigungen anfragen, die nach dem Zusammenführen im Manifest für dieses Android gelten. */
    private Set<String> declaredPermissions() {
        Set<String> s = new HashSet<>();
        try {
            String[] req = getPackageManager()
                    .getPackageInfo(getPackageName(), PackageManager.GET_PERMISSIONS).requestedPermissions;
            if (req != null) s.addAll(Arrays.asList(req));
        } catch (PackageManager.NameNotFoundException ignored) {
            // kann für die eigene App nicht passieren
        }
        return s;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMISSIONS) return;
        boolean all = grantResults.length > 0;
        for (int r : grantResults) {
            if (r != PackageManager.PERMISSION_GRANTED) all = false;
        }
        Runnable then = afterPermissions;
        afterPermissions = null;
        if (all && then != null) {
            then.run();
        } else {
            error("Ohne die Berechtigung „Geräte in der Nähe“ können sich die Handys nicht verbinden. "
                    + "Du kannst sie in den App-Einstellungen erlauben.");
        }
    }
}
