package de.quizabend.buzzer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Buzzer für den Quizabend.
 *
 * Die Oberfläche ist eine Webseite (assets/index.html). Die Handys verbinden sich über das WLAN
 * (siehe {@link LanNet}). Zusätzlich meldet sich der Raum bei der Android-Netzwerksuche an,
 * damit Mitspieler ihn auch in WLANs finden, die Broadcasts blocken.
 */
public class MainActivity extends Activity implements LanNet.Listener {

    private static final String NSD_TYPE = "_buzzer._tcp";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService control = Executors.newSingleThreadExecutor();
    private WebView web;
    private LanNet net;
    private WifiManager.MulticastLock multicastLock;

    private NsdManager nsd;
    private NsdManager.RegistrationListener nsdRegistration;
    private NsdManager.DiscoveryListener nsdDiscovery;
    private final AtomicBoolean resolving = new AtomicBoolean(false);
    private volatile String nsdName = "";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        net = new LanNet(this);
        try {
            nsd = (NsdManager) getApplicationContext().getSystemService(NSD_SERVICE);
        } catch (RuntimeException e) {
            nsd = null;
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(22, 17, 58));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidNet");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        // Erst die Webseite fragen (z. B. Raum verlassen), sonst App schließen
        web.evaluateJavascript("window.__back ? window.__back() : false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.evaluateJavascript("window.__pause && window.__pause()", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.evaluateJavascript("window.__resume && window.__resume()", null);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        event("theme", "dark", isDark() ? "1" : "0");
    }

    @Override
    protected void onDestroy() {
        final LanNet n = net;
        control.execute(() -> {
            nsdStop();
            n.stop();
            releaseMulticast();
        });
        control.shutdown();
        if (web != null) web.destroy();
        web = null;
        super.onDestroy();
    }

    // ---------------------------------------------------------------- Brücke zur Webseite

    private class Bridge {
        @JavascriptInterface
        public void startHub(String roomCode, String name) {
            control.execute(() -> {
                nsdStop();
                releaseMulticast();
                net.startHub(roomCode, name);
                int port = net.hubPort();
                if (port > 0) nsdRegister(roomCode, port);
            });
        }

        @JavascriptInterface
        public void startSpoke(String roomCode, String name) {
            control.execute(() -> {
                nsdStop();
                acquireMulticast();
                net.startSpoke(roomCode, name);
                nsdDiscover(roomCode);
            });
        }

        @JavascriptInterface
        public void connectManual(String host) {
            net.connectManual(host);
        }

        @JavascriptInterface
        public void stop() {
            control.execute(() -> {
                nsdStop();
                net.stop();
                releaseMulticast();
            });
        }

        @JavascriptInterface
        public void send(String endpointId, String data) {
            net.sendTo(endpointId, data);
        }

        @JavascriptInterface
        public void broadcast(String data) {
            net.broadcast(data);
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            main.post(() -> buzz(ms));
        }

        @JavascriptInterface
        public boolean isSystemDark() {
            return isDark();
        }

        @JavascriptInterface
        public void setSystemBars(String color, boolean light) {
            main.post(() -> applyBars(color, light));
        }
    }

    // ---------------------------------------------------------------- Android-Netzwerksuche (zweiter Weg)

    private static String nsdNameFor(String room) {
        String r = room == null ? "" : room.replaceAll("[^a-z0-9-]", "");
        return "buzzer_" + (r.isEmpty() ? "quiz" : r);
    }

    private void nsdRegister(String room, int port) {
        if (nsd == null) return;
        NsdServiceInfo info = new NsdServiceInfo();
        info.setServiceName(nsdNameFor(room));
        info.setServiceType(NSD_TYPE);
        info.setPort(port);
        NsdManager.RegistrationListener l = new NsdManager.RegistrationListener() {
            @Override
            public void onServiceRegistered(NsdServiceInfo i) { }

            @Override
            public void onRegistrationFailed(NsdServiceInfo i, int errorCode) { }

            @Override
            public void onServiceUnregistered(NsdServiceInfo i) { }

            @Override
            public void onUnregistrationFailed(NsdServiceInfo i, int errorCode) { }
        };
        try {
            nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l);
            nsdRegistration = l;
        } catch (RuntimeException ignored) {
            // dann nur der Broadcast
        }
    }

    private void nsdDiscover(String room) {
        if (nsd == null) return;
        nsdName = nsdNameFor(room);
        NsdManager.DiscoveryListener l = new NsdManager.DiscoveryListener() {
            @Override
            public void onStartDiscoveryFailed(String serviceType, int errorCode) { }

            @Override
            public void onStopDiscoveryFailed(String serviceType, int errorCode) { }

            @Override
            public void onDiscoveryStarted(String serviceType) { }

            @Override
            public void onDiscoveryStopped(String serviceType) { }

            @Override
            public void onServiceFound(NsdServiceInfo service) {
                nsdResolve(service);
            }

            @Override
            public void onServiceLost(NsdServiceInfo service) { }
        };
        try {
            nsd.discoverServices(NSD_TYPE, NsdManager.PROTOCOL_DNS_SD, l);
            nsdDiscovery = l;
        } catch (RuntimeException ignored) {
            // dann nur der Broadcast
        }
    }

    private void nsdResolve(NsdServiceInfo service) {
        String n = service.getServiceName();
        String want = nsdName;
        if (nsd == null || n == null || !(n.equals(want) || n.startsWith(want + " ("))) return;
        if (!resolving.compareAndSet(false, true)) return;
        try {
            nsd.resolveService(service, new NsdManager.ResolveListener() {
                @Override
                public void onResolveFailed(NsdServiceInfo i, int errorCode) {
                    resolving.set(false);
                }

                @Override
                @SuppressWarnings("deprecation")
                public void onServiceResolved(NsdServiceInfo i) {
                    resolving.set(false);
                    InetAddress host = i.getHost();
                    if (host != null) net.connectFound(host, i.getPort());
                }
            });
        } catch (RuntimeException e) {
            resolving.set(false);
        }
    }

    private void nsdStop() {
        if (nsd == null) return;
        NsdManager.RegistrationListener r = nsdRegistration;
        NsdManager.DiscoveryListener d = nsdDiscovery;
        nsdRegistration = null;
        nsdDiscovery = null;
        if (r != null) {
            try {
                nsd.unregisterService(r);
            } catch (RuntimeException ignored) {
                // schon abgemeldet
            }
        }
        if (d != null) {
            try {
                nsd.stopServiceDiscovery(d);
            } catch (RuntimeException ignored) {
                // schon gestoppt
            }
        }
        resolving.set(false);
    }

    // ---------------------------------------------------------------- WLAN-Rufe empfangen dürfen

    private void acquireMulticast() {
        try {
            if (multicastLock == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                if (wm == null) return;
                multicastLock = wm.createMulticastLock("buzzer");
                multicastLock.setReferenceCounted(false);
            }
            if (!multicastLock.isHeld()) multicastLock.acquire();
        } catch (RuntimeException ignored) {
            // ohne Sperre klappt die Suche auf den meisten Handys trotzdem
        }
    }

    private void releaseMulticast() {
        try {
            if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
        } catch (RuntimeException ignored) {
            // egal
        }
    }

    // ---------------------------------------------------------------- Design

    private boolean isDark() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    @SuppressWarnings("deprecation")
    private void applyBars(String color, boolean light) {
        try {
            int c = Color.parseColor(color);
            getWindow().setStatusBarColor(c);
            getWindow().setNavigationBarColor(c);
            if (web != null) web.setBackgroundColor(c);
            View decor = getWindow().getDecorView();
            int bits = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            int flags = decor.getSystemUiVisibility();
            decor.setSystemUiVisibility(light ? (flags | bits) : (flags & ~bits));
        } catch (RuntimeException ignored) {
            // ungültige Farbe: Leisten bleiben, wie sie sind
        }
    }

    // ---------------------------------------------------------------- Meldungen an die Webseite

    @Override
    public void onConnected(String endpoint) {
        event("connected", "endpoint", endpoint);
    }

    @Override
    public void onDisconnected(String endpoint) {
        event("disconnected", "endpoint", endpoint);
    }

    @Override
    public void onMessage(String endpoint, String data) {
        event("msg", "endpoint", endpoint, "data", data);
    }

    @Override
    public void onStatus(String text) {
        event("status", "text", text);
    }

    @Override
    public void onAddress(String text) {
        String t = (text == null || text.isEmpty()) ? wifiIp() : text;
        event("address", "text", t);
        if (t.isEmpty()) onStatus("Kein WLAN gefunden. Verbinde das Handy mit einem WLAN oder öffne einen Hotspot.");
    }

    /** Ersatzweg zur eigenen WLAN-Adresse, falls die Netzwerkliste leer bleibt. */
    @SuppressWarnings("deprecation")
    private String wifiIp() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wm == null || wm.getConnectionInfo() == null) return "";
            int ip = wm.getConnectionInfo().getIpAddress();
            if (ip == 0) return "";
            return (ip & 0xff) + "." + ((ip >> 8) & 0xff) + "." + ((ip >> 16) & 0xff) + "." + ((ip >> 24) & 0xff);
        } catch (RuntimeException e) {
            return "";
        }
    }

    @Override
    public void onError(String text) {
        event("error", "text", text);
    }

    private void event(String type, String... keyValues) {
        StringBuilder sb = new StringBuilder("{\"type\":").append(JSONObject.quote(type));
        for (int i = 0; i + 1 < keyValues.length; i += 2) {
            sb.append(',').append(JSONObject.quote(keyValues[i])).append(':').append(JSONObject.quote(keyValues[i + 1]));
        }
        sb.append('}');
        final String js = "window.__native && window.__native(" + sb + ")";
        main.post(() -> {
            if (web != null) web.evaluateJavascript(js, null);
        });
    }

    // ---------------------------------------------------------------- Vibration

    private void buzz(int ms) {
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) return;
        v.vibrate(VibrationEffect.createOneShot(Math.max(1, Math.min(ms, 1500)), VibrationEffect.DEFAULT_AMPLITUDE));
    }
}
