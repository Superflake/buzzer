package de.quizabend.buzzer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Buzzer für den Quizabend.
 *
 * Die Oberfläche ist eine Webseite (assets/index.html). Die Handys verbinden sich über das WLAN
 * (siehe {@link LanNet}); diese Activity reicht nur Nachrichten zwischen Webseite und WLAN durch.
 */
public class MainActivity extends Activity implements LanNet.Listener {

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService control = Executors.newSingleThreadExecutor();
    private WebView web;
    private LanNet net;
    private WifiManager.MulticastLock multicastLock;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        net = new LanNet(this);

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(22, 17, 58));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidNet");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        // Erst die Webseite fragen (z. B. Raum verlassen), sonst App schließen
        web.evaluateJavascript("window.__back ? window.__back() : false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        final LanNet n = net;
        control.execute(() -> {
            n.stop();
            releaseMulticast();
        });
        control.shutdown();
        if (web != null) web.destroy();
        web = null;
        super.onDestroy();
    }

    // ---------------------------------------------------------------- Brücke zur Webseite

    private class Bridge {
        @JavascriptInterface
        public void startHub(String roomCode, String name) {
            control.execute(() -> {
                releaseMulticast();
                net.startHub(roomCode, name);
            });
        }

        @JavascriptInterface
        public void startSpoke(String roomCode, String name) {
            control.execute(() -> {
                acquireMulticast();
                net.startSpoke(roomCode, name);
            });
        }

        @JavascriptInterface
        public void connectManual(String host) {
            net.connectManual(host);
        }

        @JavascriptInterface
        public void stop() {
            control.execute(() -> {
                net.stop();
                releaseMulticast();
            });
        }

        @JavascriptInterface
        public void send(String endpointId, String data) {
            net.sendTo(endpointId, data);
        }

        @JavascriptInterface
        public void broadcast(String data) {
            net.broadcast(data);
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            main.post(() -> buzz(ms));
        }
    }

    // ---------------------------------------------------------------- WLAN-Rufe empfangen dürfen

    private void acquireMulticast() {
        try {
            if (multicastLock == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                if (wm == null) return;
                multicastLock = wm.createMulticastLock("buzzer");
                multicastLock.setReferenceCounted(false);
            }
            if (!multicastLock.isHeld()) multicastLock.acquire();
        } catch (RuntimeException ignored) {
            // ohne Sperre klappt die Suche auf den meisten Handys trotzdem
        }
    }

    private void releaseMulticast() {
        try {
            if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
        } catch (RuntimeException ignored) {
            // egal
        }
    }

    // ---------------------------------------------------------------- Meldungen an die Webseite

    @Override
    public void onConnected(String endpoint) {
        event("connected", "endpoint", endpoint);
    }

    @Override
    public void onDisconnected(String endpoint) {
        event("disconnected", "endpoint", endpoint);
    }

    @Override
    public void onMessage(String endpoint, String data) {
        event("msg", "endpoint", endpoint, "data", data);
    }

    @Override
    public void onStatus(String text) {
        event("status", "text", text);
    }

    @Override
    public void onAddress(String text) {
        String t = (text == null || text.isEmpty()) ? wifiIp() : text;
        event("address", "text", t);
        if (t.isEmpty()) onStatus("Kein WLAN gefunden. Verbinde das Handy mit einem WLAN oder öffne einen Hotspot.");
    }

    /** Ersatzweg zur eigenen WLAN-Adresse, falls die Netzwerkliste leer bleibt. */
    @SuppressWarnings("deprecation")
    private String wifiIp() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wm == null || wm.getConnectionInfo() == null) return "";
            int ip = wm.getConnectionInfo().getIpAddress();
            if (ip == 0) return "";
            return (ip & 0xff) + "." + ((ip >> 8) & 0xff) + "." + ((ip >> 16) & 0xff) + "." + ((ip >> 24) & 0xff);
        } catch (RuntimeException e) {
            return "";
        }
    }

    @Override
    public void onError(String text) {
        event("error", "text", text);
    }

    private void event(String type, String... keyValues) {
        StringBuilder sb = new StringBuilder("{\"type\":").append(JSONObject.quote(type));
        for (int i = 0; i + 1 < keyValues.length; i += 2) {
            sb.append(',').append(JSONObject.quote(keyValues[i])).append(':').append(JSONObject.quote(keyValues[i + 1]));
        }
        sb.append('}');
        final String js = "window.__native && window.__native(" + sb + ")";
        main.post(() -> {
            if (web != null) web.evaluateJavascript(js, null);
        });
    }

    // ---------------------------------------------------------------- Vibration

    private void buzz(int ms) {
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) return;
        v.vibrate(VibrationEffect.createOneShot(Math.max(1, Math.min(ms, 1500)), VibrationEffect.DEFAULT_AMPLITUDE));
    }
}
