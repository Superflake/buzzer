# Buzzer – Android-App für den Quizabend

Wer zuerst drückt, ist dran. Danach läuft ein einstellbarer Countdown für die Antwort.

## Spielarten
- **Ein Handy für alle:** 2 bis 4 Spieler teilen sich ein Handy, jeder hat eine eigene Fläche.
- **Mehrere Handys:** Jeder hat sein eigenes Handy. Alle Handys müssen im selben WLAN sein,
  unterwegs geht auch der Hotspot eines Handys. Internet ist nicht nötig.
  - Ein Handy tippt „Spielleitung übernehmen“, ohne Spielleitung „Raum öffnen und mitspielen“.
  - Alle anderen tippen „Mitspielen“ und nehmen denselben Raumnamen.
  - Wer zuerst drückt, sperrt alle anderen. Jedes Handy zeigt an, wer es war.

## iPhones
iPhones brauchen keine App. Das Android-Handy, das den Raum öffnet, zeigt einen QR-Code.
Mit der iPhone-Kamera scannen, die Seite öffnet sich im Browser, dann „Mitspielen“ tippen.
Den Raum öffnen kann nur ein Android-Handy mit der Buzzer-App. Alle müssen im selben WLAN sein
(oder im Hotspot des Android-Handys).

## Einstellungen (Zahnrad auf der Startseite)
Musik im Hauptmenü, Lautstärke, Design (Dunkel, Hell, wie am Handy), Vibration,
Ticken im Countdown und die Antwortzeit.

## APK bauen (GitHub)
1. Im Repository unter „Add file“ → „Upload files“ diese ZIP-Datei hochladen (gleicher Name ersetzt die alte).
2. Unter „Actions“ auf den grünen Haken warten (ca. 2 Minuten).
3. Unter „Releases“ beim obersten Eintrag `Buzzer.apk` laden und installieren.

## Wenn der Raum nicht gefunden wird
- Sind alle im selben WLAN? Gäste-WLANs blockieren oft die Verbindung zwischen Geräten,
  dann ein normales WLAN oder den Hotspot eines Handys nehmen.
- Der Raum wird auf zwei Wegen gesucht: per WLAN-Broadcast und über die Android-Netzwerksuche.
- Die Adresse steht auf dem Raum-Handy unten („Adresse dieses Handys“). Nach ein paar Sekunden
  erscheint bei den Mitspielern ein Feld, in das man sie eintippen kann.

## Technik
- Oberfläche: `app/src/main/assets/index.html`
- WLAN-Verbindung: `app/src/main/java/de/quizabend/buzzer/LanNet.java`
  (Suche per UDP-Broadcast auf Port 47810, Spiel per TCP auf Port 47811,
  Webseite für iPhones auf Port 47812 mit Server-Sent Events)
- Läuft ab Android 8, ohne Google-Dienste und ohne besondere Berechtigungen.
- Der Signaturschlüssel `app/buzzer.jks` bleibt gleich, damit sich neue Versionen über die alte installieren lassen.
