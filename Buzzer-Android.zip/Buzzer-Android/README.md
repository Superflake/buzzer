# Buzzer – Android-App mit Bluetooth

Die Handys verbinden sich direkt über Bluetooth und WLAN (Google „Nearby Connections“).
Internet und Konto braucht ihr nicht. Nur wer zuerst drückt, klingelt.

## APK bauen

### Variante A: GitHub (nichts installieren)
1. Kostenloses Konto auf github.com anlegen und ein neues Repository erstellen, z. B. „buzzer“.
   Wenn deine Freunde die APK selbst herunterladen sollen, mach es öffentlich.
2. Am PC „Add file“ → „Upload files“ und den kompletten Inhalt dieses Ordners hineinziehen,
   auch den Ordner `.github` (am Mac im Finder mit Cmd + Shift + Punkt sichtbar machen).
3. „Commit changes“ klicken. GitHub baut die App jetzt automatisch (Reiter „Actions“, ca. 5 Minuten).
4. Danach unter „Releases“ die Datei `Buzzer.apk` herunterladen.

### Variante B: Android Studio (am PC)
1. Android Studio installieren: developer.android.com/studio
2. „Open“ → diesen Ordner wählen und warten, bis die Gradle-Synchronisierung fertig ist
   (beim ersten Mal lädt Android Studio einiges herunter).
3. Menü „Build“ → „Build APK(s)“ (in neueren Versionen „Generate App Bundles or APKs“ → „Generate APKs“).
4. Die APK liegt dann unter `app/build/outputs/apk/debug/`.

## Installieren
- APK aufs Handy laden oder per Quick Share an die anderen schicken und antippen.
- Android fragt, ob Apps aus dieser Quelle installiert werden dürfen: erlauben.
- Warnt Google Play Protect vor einer unbekannten App: „Trotzdem installieren“.

## Spielen
- Bluetooth und WLAN einschalten. Bei Android 8 bis 11 zusätzlich den Standort einschalten.
- Ein Handy tippt „Spielleitung übernehmen“, ohne Spielleitung „Raum öffnen und mitspielen“.
  Alle anderen tippen „Mitspielen“ und nehmen denselben Raumnamen.
- Beim ersten Start die Berechtigung „Geräte in der Nähe“ erlauben.
- Das Handy, das den Raum geöffnet hat, entscheidet, wer zuerst gedrückt hat. Sobald jemand buzzert,
  sind alle anderen Buzzer gesperrt und jedes Handy zeigt an, wer es war.
- Unten auf jedem Handy stehen alle, die im Raum sind. Fehlt dort jemand, ist er nicht verbunden.

## Gut zu wissen
- Läuft ab Android 8. Die Handys brauchen die Google-Play-Dienste
  (fast alle Android-Handys haben sie, neuere Huawei-Geräte nicht). iPhones können nicht mitspielen.
- Pro Raum sollte nur ein Handy den Raum öffnen.
- Der Signaturschlüssel `app/buzzer.jks` liegt bei, damit sich neue Versionen über die alte installieren lassen.
